# AUREA CORE — Unified Quantum Evolution v12.0 (ES/EN)

Autonomous Web3 portal uniting AI, decentralized storage (IPFS/Filecoin), and a multi-token economy (AQR, ATI, LUMIA, BSG, MindTokens).

## Deploy
- GitHub Pages / Netlify / Vercel (static)
- Pinata / Web3.Storage (IPFS/Filecoin)
- No backend required

## How to use
1) Upload the whole folder to GitHub or Pinata (keep structure).
2) Open `index.html`; language auto-detects (ES/EN).
3) Connect Phantom to test wallet actions (client-side stubs).
4) Use token scanner to fetch live pairs via Dexscreener.

## Wire on-chain
- Replace stubs in /modules/* with real Solana program calls.
- Save XAI logs to IPFS and store CIDs on-chain.
