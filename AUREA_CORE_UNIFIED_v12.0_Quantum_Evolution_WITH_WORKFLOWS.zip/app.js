import { initLang, toggleLang, currentLang } from './modules/i18n.js';
import { connectWallet } from './modules/wallet_solana.js';
import { scanToken } from './modules/token_scanner.js';
import { dao } from './modules/dao_governance.js';
import { xai } from './modules/xai_resonance.js';
document.addEventListener('DOMContentLoaded', async () => {
  await initLang();
  document.getElementById('btnLang').addEventListener('click', toggleLang);
  const btnConnect = document.getElementById('btnConnect');
  btnConnect.addEventListener('click', async () => {
    const ok = await connectWallet();
    if(ok){ btnConnect.textContent = (currentLang()==='es' ? 'Conectado' : 'Connected'); }
  });
  const form = document.getElementById('tokenForm');
  form.addEventListener('submit', async (e)=>{
    e.preventDefault();
    const q = document.getElementById('tokenQuery').value.trim();
    await scanToken(q, document.getElementById('tokenResult'));
  });
  document.getElementById('btnNewProposal').addEventListener('click', ()=> dao.newProposal());
  document.getElementById('btnVote').addEventListener('click', ()=> dao.vote());
  document.getElementById('btnStake').addEventListener('click', ()=> dao.stake());
  document.getElementById('btnExplain').addEventListener('click', ()=> xai.explain());
  document.getElementById('btnExport').addEventListener('click', ()=> xai.exportLogs());
  try{
    const m = location.hostname.match(/([a-z0-9]{46,})/);
    document.getElementById('ipfsCid').textContent = m ? m[1] : (localStorage.getItem('AUREA_IPFS_CID') || '—');
  }catch{}
});