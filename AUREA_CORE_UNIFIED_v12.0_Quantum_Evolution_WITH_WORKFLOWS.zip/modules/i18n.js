let lang = 'en';
export function currentLang(){ return lang; }
export async function initLang(){
  const userLang = (navigator.language || navigator.userLanguage || 'en').toLowerCase();
  lang = userLang.startsWith('es') ? 'es' : 'en';
  await loadLanguage(lang);
  document.getElementById('langLabel').textContent = lang.toUpperCase();
}
export async function toggleLang(){
  lang = (lang==='es') ? 'en' : 'es';
  await loadLanguage(lang);
  document.getElementById('langLabel').textContent = lang.toUpperCase();
  localStorage.setItem('AUREA_LANG', lang);
}
async function loadLanguage(l){
  try{
    const res = await fetch(`./lang/${l}.json?ts=${Date.now()}`);
    const data = await res.json();
    for(const [key,val] of Object.entries(data)){
      const el = document.querySelector(`[data-i18n="${key}"]`);
      if(el) el.innerHTML = val;
    }
  }catch(e){ console.warn('i18n load failed', e); }
}