function usd(n){ if(n==null||isNaN(n)) return '$—'; const x=Number(n); return (x>=1? `$${x.toLocaleString(undefined,{maximumFractionDigits:2})}` : `$${x.toLocaleString(undefined,{maximumSignificantDigits:3})}`); }
function pc(n){ if(n==null||isNaN(n)) return '—'; const x=Number(n); return `${x>0?'+':''}${x.toFixed(2)}%`; }
export async function scanToken(q, mount){
  mount.innerHTML = '<p class="muted">Loading…</p>';
  try{
    let data;
    const isAddr = /^(0x)?[a-zA-Z0-9]{32,64}$/.test(q) || q.includes('/');
    if(isAddr){
      const r = await fetch('https://api.dexscreener.com/latest/dex/tokens/'+encodeURIComponent(q));
      data = await r.json();
    }else{
      const r = await fetch('https://api.dexscreener.com/latest/dex/search/?q='+encodeURIComponent(q));
      data = await r.json();
    }
    const pairs = (data && data.pairs) ? data.pairs : [];
    if(!pairs.length){ mount.innerHTML = '<p class="muted">No pairs found.</p>'; return; }
    const best = pairs.slice().sort((a,b)=>(b.liquidity?.usd||0)-(a.liquidity?.usd||0))[0];
    const cards = pairs.slice(0,16).map(p=>renderPair(p)).join('');
    mount.innerHTML = cards;
    const el = mount.querySelector(`[data-pair="${best.pairAddress||''}"]`);
    if(el) el.style.borderColor = '#17e0ff';
  }catch(e){
    console.error(e); mount.innerHTML = '<p class="muted">Error fetching data.</p>';
  }
}
function renderPair(p){
  return `<div class="pair" data-pair="${p.pairAddress||''}">
    <h4>${p.baseToken?.symbol||'?'} / ${p.quoteToken?.symbol||'?'} <small>• ${p.chainId||''}</small></h4>
    <div class="grid" style="margin-top:6px">
      <div class="kv"><span>Price</span><b>${usd(Number(p.priceUsd))}</b></div>
      <div class="kv"><span>24h</span><b>${pc(Number(p.priceChange24h))}</b></div>
      <div class="kv"><span>Liquidity</span><b>${usd(Number(p.liquidity?.usd))}</b></div>
      <div class="kv"><span>Vol 24h</span><b>${usd(Number(p.volume?.h24))}</b></div>
      <div class="kv"><span>FDV</span><b>${usd(Number(p.fdv))}</b></div>
    </div>
  </div>`;
}