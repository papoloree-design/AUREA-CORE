export const dao = {
  newProposal(){ logXAI('DAO:newProposal', {ts:Date.now(), by: (localStorage.getItem('AUREA_WALLET')||'anon')}); alert('Proposal created (stub).'); },
  vote(){ logXAI('DAO:vote', {ts:Date.now(), weight: 1}); alert('Vote submitted (stub).'); },
  stake(){ logXAI('DAO:stake', {ts:Date.now(), amount: 0}); alert('Stake initiated (stub).'); }
};
function logXAI(event, payload){
  const raw = localStorage.getItem('AUREA_XAI') || '[]';
  const arr = JSON.parse(raw); arr.push({event, payload}); localStorage.setItem('AUREA_XAI', JSON.stringify(arr));
  const el = document.getElementById('xaiLog'); if(el){ el.textContent = JSON.stringify(arr, null, 2); }
}