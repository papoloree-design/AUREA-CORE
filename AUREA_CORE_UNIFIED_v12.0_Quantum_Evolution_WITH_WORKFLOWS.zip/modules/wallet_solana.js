export async function connectWallet(){
  try{
    const provider = window.solana;
    if (!provider || !provider.isPhantom){
      alert('Phantom not found. Install Phantom wallet.');
      return false;
    }
    const resp = await provider.connect();
    localStorage.setItem('AUREA_WALLET', resp.publicKey.toString());
    return true;
  }catch(e){
    console.error(e); alert('Wallet connection failed'); return false;
  }
}